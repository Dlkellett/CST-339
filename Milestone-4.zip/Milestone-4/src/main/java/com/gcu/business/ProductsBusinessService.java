package com.gcu.business;

import java.util.ArrayList; 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.gcu.data.OrdersDataService;
import com.gcu.data.ProductsDataService;
import com.gcu.data.entity.OrderEntity;
import com.gcu.data.entity.ProductsEntity;
import com.gcu.model.OrderModel;
import com.gcu.model.ProductsModel;

public class ProductsBusinessService implements ProductsBusinessServiceInterface
{
	@Autowired
	ProductsDataService productsService;
	
	// The list of products
	List<ProductsModel> products;
	public ProductsBusinessService() 
	{
		this.products = new ArrayList<ProductsModel>();
	}
	
	public List<ProductsModel> getProducts() 
	{
		// Get all all the Entity Products
	    List<ProductsEntity> productsEntity = productsService.findAll();
	    // Iterate over the Entity Products and create a list of Domain Products
	    List<ProductsModel> productsDomain = new ArrayList<ProductsModel>();
	    
	    for (ProductsEntity entity : productsEntity)
	    {
	    	productsDomain.add(new ProductsModel(entity.getImage(), entity.getLength(), entity.getMeasuremeantUnit(), entity.getWeight(), entity.getDescription()));
	    }
	    // Return list of Domain Products
	    return productsDomain;
	}
	
	public void addProduct(ProductsModel productsModel)
	{
		// Adds a product to the list
		products.add(new ProductsModel(productsModel.getJpgImage(), productsModel.getTapeMeasureLength(), productsModel.getTMMU(), productsModel.getTapeWeight(), productsModel.getTapeDescription()));
	}
}
