package com.gcu.data.repository;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;

import com.gcu.data.entity.RegisterEntity;

public interface RegisterRepository extends CrudRepository<RegisterEntity, Long>
{
	@Override
	@Query(value = "SELECT * FROM tapemeasureheaven.user" )
	Iterable<RegisterEntity> findAll();
}
