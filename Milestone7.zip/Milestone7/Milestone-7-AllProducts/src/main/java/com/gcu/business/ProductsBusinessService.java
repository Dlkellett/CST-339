package com.gcu.business;

import java.util.ArrayList; 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gcu.data.entity.ProductsEntity;
import com.gcu.data.repository.ProductsRepository;
import com.gcu.model.ProductsModel;

@Service
public class ProductsBusinessService implements ProductsBusinessServiceInterface
{
	@Autowired
	ProductsRepository productsRepository;
	
	/**
	 * Parameterized (Non-Default) constructor for constructor injection
	 */
	public ProductsBusinessService(ProductsRepository productsRepository) 
	{
		this.productsRepository = productsRepository;
	}
	
	public List<ProductsModel> getProducts() 
	{
		/**
		 *  Get all the Entity Products
		 */
	    List<ProductsEntity> productsEntity = productsRepository.findAll();
	    /**
	     *  Iterate over the Entity Products and create a list of Domain Products
	     */
	    List<ProductsModel> productsDomain = new ArrayList<ProductsModel>();
	    
	    for (ProductsEntity entity : productsEntity)
	    {
	    	productsDomain.add(new ProductsModel(entity.getProduct_id(), entity.getImage(), entity.getLength(), entity.getMeasuremeantUnit(), entity.getWeight(), entity.getDescription()));
	    }
	    /**
	     *  Return list of Domain Products
	     */
	    return productsDomain;
	}
}
