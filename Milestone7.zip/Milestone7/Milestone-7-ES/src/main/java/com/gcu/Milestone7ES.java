package com.gcu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class Milestone7ES {

	public static void main(String[] args) {
		SpringApplication.run(Milestone7ES.class, args);
	}

}
