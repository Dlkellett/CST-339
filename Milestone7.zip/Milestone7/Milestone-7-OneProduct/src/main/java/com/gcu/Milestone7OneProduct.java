package com.gcu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class Milestone7OneProduct {

	public static void main(String[] args) {
		SpringApplication.run(Milestone7OneProduct.class, args);
	}

}
