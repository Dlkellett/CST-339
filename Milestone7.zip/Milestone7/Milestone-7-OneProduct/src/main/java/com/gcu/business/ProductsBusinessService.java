package com.gcu.business;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gcu.data.entity.ProductsEntity;
import com.gcu.data.repository.ProductsRepository;
import com.gcu.model.ProductsModel;

@Service
public class ProductsBusinessService implements ProductsBusinessServiceInterface
{
	@Autowired
	ProductsRepository productsRepository;
	
	/**
	 * Parameterized (Non-Default) constructor for constructor injection
	 */
	public ProductsBusinessService(ProductsRepository productsRepository) 
	{
		this.productsRepository = productsRepository;
	}
	
	public ProductsModel getProduct(Long id) 
	{
		/**
		 * find a product by id
		 */
		Optional<ProductsEntity> productEntity = productsRepository.findById(id);
		/**
		 * convert that product to a ProductsModel
		 */
		ProductsModel product = new ProductsModel(productEntity.get().getProduct_id(), 
				productEntity.get().getImage(), productEntity.get().getLength(), 
				productEntity.get().getMeasuremeantUnit(), productEntity.get().getWeight(), 
				productEntity.get().getDescription());
	    return product;
	}
}
