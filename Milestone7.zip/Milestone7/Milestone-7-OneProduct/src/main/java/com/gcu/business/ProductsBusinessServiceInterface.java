package com.gcu.business;

import com.gcu.model.ProductsModel;

public interface ProductsBusinessServiceInterface 
{
	public ProductsModel getProduct(Long id);
}
