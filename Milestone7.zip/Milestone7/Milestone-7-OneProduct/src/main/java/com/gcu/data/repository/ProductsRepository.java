package com.gcu.data.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.gcu.data.entity.ProductsEntity;

/**
 * Associate the Spring repository with the ProductsEntity class.
 */
public interface ProductsRepository extends CrudRepository<ProductsEntity, Long>
{
	/**
	 * Will call to the findById method that has been created, selecting from 
	 * the tapemeasurehaven.products database table.
	 */
	@Override
	public Optional<ProductsEntity> findById(Long id);
}