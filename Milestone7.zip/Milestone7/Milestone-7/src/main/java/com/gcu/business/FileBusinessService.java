package com.gcu.business;

import java.io.File;
import java.io.FileOutputStream;

import com.gcu.model.ProductsModel;

/**
 * receives a ProductsModel and copies the image to the images folder
 * @author JGwozdz
 *
 */
public class FileBusinessService {
	public Boolean copyFile(ProductsModel productsModel) {
		String filePath = System.getProperty("user.dir") + "/src/main/resources/static/images";
		String fileName = productsModel.getImageFile().getOriginalFilename();
		
		File copy = new File(filePath, fileName);
		
		try {
			if (copy.createNewFile()) {
				
			    FileOutputStream newer = new FileOutputStream(copy);
			    
			    byte[] bytes = productsModel.getImageFile().getBytes();
			    newer.write(bytes);
			    
			    newer.close();
			    Thread.sleep(3000);
	            return true;
			}
			else {
				Thread.sleep(3000);
				return true;
			}
		}catch(Exception e) {
			System.out.println("ERROR!");
			e.printStackTrace();
		}
		return false;
	}
}
