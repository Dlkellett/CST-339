package com.gcu.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.gcu.business.FileBusinessService;
import com.gcu.business.LoginBusinessService;
import com.gcu.business.ProductsBusinessServiceInterface;
import com.gcu.model.LoginModel;
import com.gcu.model.ProductsModel;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;

@Controller
@RequestMapping("/login")
public class LoginController 
{
	/**
	 * Autowiring for all of the various beans that are being made throughout the program. 
	 * ProductsBusinessServiceInterface, LoginBusinessService, RegisterBusinessServiceInterface.
	 */
	@Autowired
	public ProductsBusinessServiceInterface productService;
	@Autowired
	public LoginBusinessService loginService;
	/**
	 * Inject an instance variable name eurekaClient
	 * of type EurekaClient as a class scoped variable
	 */
	@Autowired
	private EurekaClient eurekaClient;
	/**
	 * handles the manipulation of pictures
	 */
	@Autowired
	FileBusinessService fileService;
	
	/**
	 * Basically the home of the whole application, just a simple "/".
	 * More accurately the login of the application.
	 */
	@GetMapping("/")
	public String display(Model model)
	{
		/**
		 *  Display login form view 
		 */
		model.addAttribute("title", "Now it is time to Login!");
		model.addAttribute("loginModel", new LoginModel());
		return "login";
	}
	
	/**
	 * Mapping for the products page
	 */
	@GetMapping("/products")
	public String productsPage(Model model)
	{
		model.addAttribute("title", "Now enter in the product that you want to add!");
		model.addAttribute("productsModel", new ProductsModel());
		return "products";
	}	
	
	/**
	 * Mapping for the reviews page
	 */
	@GetMapping("/reviews")
	public String reviewsPage(Model model)
	{
		model.addAttribute("title", "This is where the reviews will be!");
		return "reviews";
	}
	
	/**
	 * Mapping for the personalProductPage
	 */
	@GetMapping("/personalProductPage")
	public String personalProductPage(Model model)
	{	
		/**
		 * Lookup the host name and port for the Products Rest API
		 * import com.netflix.discovery.shared.application
		 * lookup the products-service(Eureka App) by calling the getApplication
		 */
		Application application = eurekaClient.getApplication("products-service");
		/**
		 * Get the first instance of the app into instanceInfo
		 */
		InstanceInfo instanceInfo = application.getInstances().get(0);
		/**
		 * Get the hostname and port from the instanceInfo
		 */
		String hostname = instanceInfo.getHostName();
		int port = instanceInfo.getPort();
		
		String url = "http://" + hostname + ":" + port + "/service/products";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<List<ProductsModel>> rateResponse = restTemplate.exchange(url, HttpMethod.GET, null, new ParameterizedTypeReference<List<ProductsModel>>() {});
		List<ProductsModel> products = rateResponse.getBody();
		
		model.addAttribute("title", "You have successfully seen your products!");
		model.addAttribute("empty", products.isEmpty());
		model.addAttribute("products", products);
		return "personalProductPage";
	}
	
	/**
	 * All the POST mapping is below, all of the GET mapping is above.
	 */
	
	/**
	 * POST from the update button to confirm updating a product 
	 */
	@PostMapping("/updateProduct")
	public String updateProduct(ProductsModel productsModel, Model model)
	{
		/**
		 * Lookup the host name and port for the Product Rest API
		 * import com.netflix.discovery.shared.application
		 * lookup the product-service(Eureka App) by calling the getApplication
		 */
		Application application = eurekaClient.getApplication("product-service");
		/**
		 * Get the first instance of the app into instanceInfo
		 */
		InstanceInfo instanceInfo = application.getInstances().get(0);
		/**
		 * Get the hostname and port from the instanceInfo
		 */
		String hostname = instanceInfo.getHostName();
		int port = instanceInfo.getPort();
		
		String url = "http://" + hostname + ":" + port + "/service/product/" + productsModel.getProductId();
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<ProductsModel> rateResponse = restTemplate.exchange(url, HttpMethod.GET, null, new ParameterizedTypeReference<ProductsModel>() {});
		ProductsModel product = rateResponse.getBody();
		
		model.addAttribute("title", "You are attempting to edit a product");
		model.addAttribute("product", product);
		model.addAttribute("productsModel", new ProductsModel());
		return "updateProduct";
	}
	
	/**
	 * POST from the delete button to confirm deletion of a product.
	 */
	@PostMapping("/deleteProduct")
	public String deleteProduct(ProductsModel productsModel, Model model)
	{
		model.addAttribute("title", "You are attempting to delete a product");
		model.addAttribute("productsModel", productsModel);
		return "deleteProduct"; 
	}
	
	/**
	 * POST to be able to process the products that will allow for someone to see their very own products page
	 */
	@PostMapping("/processProduct")
	public String processProduct(@Valid ProductsModel productsModel, BindingResult bindingResult, Model model)
	{	
		if (bindingResult.hasErrors())
		{
			return "products";
		}
		
		if (fileService.copyFile(productsModel)) {
			productsModel.setImage(productsModel.getImageFile().getOriginalFilename());
		}
		else {
			productsModel.setImage("TesterImage.jpg");
		}
		
		productService.addProduct(productsModel);
		model.addAttribute("title", "You have successfully seen your products!");
		model.addAttribute("empty", productService.getProducts().isEmpty());
		model.addAttribute("products", productService.getProducts());
		
		return "personalProductPage";
	}
	
	/**
	 * POST that will be updating a product
	 */
	@PostMapping("/processUpdate")
    public String processUpdate(@Valid ProductsModel productsModel, BindingResult bindingResult, Model model)
    {
        if (bindingResult.hasErrors())
        {
            return "products";
        }

        if (fileService.copyFile(productsModel)) {
			productsModel.setImage(productsModel.getImageFile().getOriginalFilename());
		}
		else {
			productsModel.setImage("TesterImage.jpg");
		}
        productService.updateProduct(productsModel);
        model.addAttribute("title", "You have successfully updated your product!");
        model.addAttribute("empty", productService.getProducts().isEmpty());
        model.addAttribute("products", productService.getProducts());

        return "personalProductPage";
    }
	
	/**
	 * POST that will be deleting a product
	 */
	@PostMapping("/processDelete")
    public String processDelete(ProductsModel productsModel, Model model)
    {
		System.out.println(productsModel.toString());
        productService.deleteProduct(productsModel);
        model.addAttribute("title", "You have successfully deleted your product!");
        model.addAttribute("empty", productService.getProducts().isEmpty());
        model.addAttribute("products", productService.getProducts());

        return "personalProductPage";
    }
}
